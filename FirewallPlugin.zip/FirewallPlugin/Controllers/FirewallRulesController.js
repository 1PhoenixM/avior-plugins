//FirewallRulesController.js

//In Sails.js, every Model file you create will work with its corresponding Controller file.
//Models are the core data, and Controllers contain the logic for the API.
//You can also bind "actions" to your model routes here.
//Names: "AviorModel.js" matches up with "AviorController.js"

module.exports = {

  identity: 'firewallrules', //must be same as corresponding model identity

  _config: {actions: true, rest: true, shortcuts: true},

  index: function(req, res){
	return res.send("The FirewallRules controller is functioning properly!");
      //bound at localhost:1337/avior/index, where the message will be displayed.
  },
    
  create: function(req, res){
        var floodlight = require('../adapters/FloodlightAdapter');
        var opendaylight = require('../adapters/OpenDaylightAdapter');
        if(sails.controllers.main.sdncontroller === 'floodlight'){
            var Adapter = floodlight;    
        }
        else if(sails.controllers.main.sdncontroller === 'opendaylight'){
            var Adapter = opendaylight;
        }
        else{
            console.log("Firewall rule add error: No controller specified at localhost:1337");
            return;
        }
        Adapter.create(sails.controllers.main.sdncontroller, 'firewallrules', {data: req.body, response: res}, null);   
      
  },
    
  destroy: function(req, res){
        var floodlight = require('../adapters/FloodlightAdapter');
        var opendaylight = require('../adapters/OpenDaylightAdapter');
        if(sails.controllers.main.sdncontroller === 'floodlight'){
            var Adapter = floodlight;    
        }
        else if(sails.controllers.main.sdncontroller === 'opendaylight'){
            var Adapter = opendaylight;
        }
        else{
            console.log("Firewall rule delete error: No controller specified at localhost:1337");
            return;
        }
        Adapter.destroy(sails.controllers.main.sdncontroller, 'firewallrules', {data: req.body, response: res}, null);
      
  },

  anAction: function(req, res){
	//accessible at localhost:1337/<model name>/anAction
  },

};

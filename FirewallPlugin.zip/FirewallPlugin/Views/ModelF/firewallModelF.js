define([
	"backbone",
	"util",
	"openflow"
], function(Backbone,Util){
	/* Structure to hold pushed firewall attributes */
	var FirewallEdModel = Backbone.Model.extend();
	return FirewallEdModel;
});
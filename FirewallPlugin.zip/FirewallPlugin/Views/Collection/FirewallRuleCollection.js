 define([
	"backbone",
	"util",
	"model/FirewallRuleModelF",
], function(Backbone,Util,FirewallRule){
	/* Structure to hold firewall rules */
	/* Structure to hold flow models */
	var FirewallRuleCollection = Backbone.Collection.extend({
		model: FirewallRuleModelF,
		url: Util.missingCtlrErr,
        comparator: function(rule){
                        var ids = rule.get("RuleID");
                        return "";
                },
	});
	return FirewallRuleCollection;
});
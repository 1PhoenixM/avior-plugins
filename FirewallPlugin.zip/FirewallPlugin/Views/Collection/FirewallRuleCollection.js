 define([
	"backbone",
	"util",
	"model/FirewallRuleModelF",
], function(Backbone,Util,FirewallRule){
	/* Structure to hold firewall rules */
	var FirewallRuleCollection = Backbone.Collection.extend({
		model: FirewallRule,
		url: Util.missingCtlrErr,
	});
	return FirewallRuleCollection;
});
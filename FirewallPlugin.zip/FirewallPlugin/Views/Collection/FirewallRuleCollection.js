 define([
	"backbone",
	"util",
	"model/FirewallRuleModelF",
], function(Backbone,Util,FirewallRule){
	/* Structure to hold firewall rules */
	/* Structure to hold flow models */
	var FirewallRuleCollection = Backbone.Collection.extend({
		model: FirewallRule,
		url: Util.missingCtlrErr,
        url: function() {return "/firewallrules/find";},
        comparator: function(rule){
                        var id = rule.get("RuleID");
                        return this.id;
        },
	});
	return FirewallRuleCollection;
});
//FirewallView.js
//The view decides the behavior of the front-end.
//Create a new instance of your API file, then perform a .fetch() to get data.
//Provide a view file for HTML elements that render with data, such as tables and divs
//Render will render your HTML template with the data inside (example, your use case may vary):
//    this.$el.html(this.template({Tests: this.collection.models})).trigger('create');
//    return this;
//You can also provide a refresh button to get any changes from the SDN controller.
//http://backbonejs.org/#View

define([
	"jquery",
	"underscore",
	"backbone",
	"marionette",
	"floodlight/FirewallRuleAPI",
	"text!template/ruletpl.html"
], function($, _, Backbone, Marionette, Firewall, ruleTpl){
	var FirewallView = Backbone.View.extend({
	    //tagName: "div",
	    el: $('#content'),
        
		template: _.template(ruleTpl),
		
		initialize: function(){
			var self = this;
			this.model = new Firewall();
			this.model.fetch();
			this.collapsed = true;
			// Update the collection when changes occur
			this.listenTo(this.model, "sync", this.render);
            
		},
		
		events: {
			"click #refresh": "refresh",
		},
		
		
		// Render the collection
	    render: function() {
			//this.$el.html(this.template({Role: this.model})).trigger('create');
            this.$el.html( this.template(this.model.toJSON()));
            //this.$el.html(this.template(this.model.toJSON()));
			return this;
	    },
		refresh: function(){this.model.fetch();},
		
		
	});
	return FirewallView;
});


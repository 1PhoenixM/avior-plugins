//pluginrouter.js
//This sets up routes in the GUI.


define([
	"jquery",
	"underscore",
	"backbone",
	"marionette",
	"text!template/login.html",
	"text!template/controller.html",
	"text!template/content.html",
    "text!template/ruletpl.html",
    "floodlight/FirewallRuleAPI",
    "view/FirewallView",
    "floodlight/firewallModAPI",
    "view/firewallEditorView",
    "view/switchDetail",
    "floodlight/switch"
], function($, _, Backbone, Marionette, loginTpl, controllerTpl, contentTpl, ruleTpl, Firewall, FirewallView, FirewallMod, FirewallEditor, SwitchDetail, Switch){
	
    //Adds your plugin to the menu
    //Todo: put in own function in initialize.
    var menuOption = '<input data-rel="close" id="firewallView" class="link" type="button" value="Firewall" onclick="location.href="#firewall";">';
    var rulesOption = '<input data-rel="close" id="rulesView" class="link" type="button" value="Firewall Rules" onclick="location.href="#firewallrules";">';
    //Updates visual styling
    $('#aviorMenu').append(menuOption).trigger('create');
    $('#aviorMenu').append(rulesOption).trigger('create');
    
    $('#firewallView').click(function () {
        window.location="#firewall"; 
    });
    
    $('#rulesView').click(function () {
        window.location="#firewallrules"; 
    });
    
    //Optional code will be loaded with the router. Here's the code for a firewall toggle button
    if($( "#firewallToggle" ).length){
            fm = new FirewallMod("status");
			fm.fetch().complete(function () {
			firewallStatus = fm.get("0");
            //Since ODL doesn't have firewall support. Doing this to avoid getting undefined and having sails crash.
            console.log(firewallStatus);
            if (firewallStatus !== undefined){
            switch (firewallStatus.Result){
                case 'firewall enabled':$( "#radio-choice-c" ).prop( "checked", true );
                                        $( "#radio-choice-d" ).prop( "checked", false );
                                        //$("#radio-choice-c").prop("disabled", true);
                                        //$("#radio-choice-d").prop("disabled", false);
                        break;
				case 'firewall disabled':$( "#radio-choice-d" ).prop( "checked", true );
                                         $( "#radio-choice-c" ).prop( "checked", false );
                                         //$("#radio-choice-d").prop("disabled", true);
                                         //$("#radio-choice-c").prop("disabled", false);
                        break;
                default:
                        break;
				}
            }
            else{
                $( "#firewallToggle" ).css('display', 'none');   
            }
			$('#content').append(this.template3).trigger('create');		
			},this);   
    }    
    
    /* Structure used to navigate through views */
	var PluginRouter = Marionette.AppRouter.extend({
		template: _.template(controllerTpl),
		template2: _.template(loginTpl),
		template3: _.template(contentTpl),
        template4: _.template(ruleTpl),
		
		routes: {
			//"firewallrules" : "firewallRulesRoute", 
            "firewall": "firewallRoute",
            "firewallrules": "rulesRoute"
		},
		
            
        /*firewallRulesRoute: function() {
			$('#content').empty();
			$('#leftPanel').empty();
			$('#rightPanel').empty();
			$('#content').append('<img class="innerPageLoader" src="img/ajax-loader.gif" />');
			
			// Clears out any previous intervals
			clearInterval(this.interval);
			
			// Create view
			this.firewallview = new FirewallView({model: new Firewall});
			
            console.log(this.firewallview);
            
			// Delegate events for view
			this.firewallview.delegateEvents(this.firewallview.events);
			
			this.firewallCollection = this.firewallview.model;  
			
			document.title = 'Avior - Firewall';
			
			//Set up dual-panel interface. Remove if not wanted
			//layout = new FrontPage();
			//layout.topologyShow();
			
			// Link to id tag
			$('#content').empty();
			$('#content').append(this.template4).trigger('create');
			$('#content').append(this.firewallview.render().el).trigger('create');
			
        },*/
        
          firewallRoute: function() {
        	$('#content').empty();
        	$('#leftPanel').empty();
			$('#rightPanel').empty();
			$('#content').prepend('<img class="innerPageLoader" src="img/ajax-loader.gif" />');

			// Clears out any previous intervals
			clearInterval(this.interval);
			
			document.title = 'Avior - Firewall';
			
			if (this.switchCollection === undefined){
				var switchDetail = new SwitchDetail({model: new Switch});
				switchDetail.delegateEvents(switchDetail.events);
				switchDetail.listenTo(switchDetail.switchStats, "sync", function () {new FirewallEditor(switchDetail.collection, true);});
			}
			else
				new FirewallEditor(this.switchCollection, true, false);
			$('#content').append(this.template3).trigger('create');
			
            this.firewallview = new FirewallView({model: new Firewall});
			
            console.log(this.firewallview);
            
			// Delegate events for view
			this.firewallview.delegateEvents(this.firewallview.events);
			
			this.firewallCollection = this.firewallview.model;  
              
            $('#content').append(this.template4).trigger('create');
			$('#content').append(this.firewallview.render().el).trigger('create');  
              
            //layout = new FrontPage();
			//layout.controllerShow();
            //layout.hostShow();
            //layout.switchShow();
            //layout.topologyShow();
            //layout.staticFlowShow();
			
        },
        
        rulesRoute: function() {
            $('#content').empty();
        	$('#leftPanel').empty();
			$('#rightPanel').empty();
			$('#content').prepend('<img class="innerPageLoader" src="img/ajax-loader.gif" />');

			// Clears out any previous intervals
			clearInterval(this.interval);
			
			document.title = 'Avior - Firewall Rules';
			
			/*if (this.switchCollection === undefined){
				var switchDetail = new SwitchDetail({model: new Switch});
				switchDetail.delegateEvents(switchDetail.events);
				switchDetail.listenTo(switchDetail.switchStats, "sync", function () {new FirewallEditor(switchDetail.collection, true);});
			}*/
			//else
            //new FirewallEditor(this.switchCollection, true, false);
			$('#content').append(this.template3).trigger('create');
			
            this.firewallview = new FirewallView({model: new Firewall});
			
            console.log(this.firewallview);
            
			// Delegate events for view
			this.firewallview.delegateEvents(this.firewallview.events);
			
			this.firewallCollection = this.firewallview.model;  
              
            $('#content').append(this.template4).trigger('create');
            $('#content').append(this.firewallview.render().el).trigger('create');  
        },

	});
	return PluginRouter;
}); 
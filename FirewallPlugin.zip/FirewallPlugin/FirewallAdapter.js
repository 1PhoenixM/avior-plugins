//FirewallAdapter.js
//Fill out all properties in this object as they apply to your plugin.
var http = require('http');
var restCall = function(apiMethod,apiPath){
        var self = this;
        return function(options,cb){
                var rawPath = apiPath;
                if (options.args){
                        for (arg in options.args){
                                apiPath = apiPath.replace(/:[A-Za-z]+:/, options.args[arg]);
                        }
                }
                if(sails.controllers.main.hostname){
                  var host = sails.controllers.main.hostname;
                }
                opts = {method:apiMethod,hostname:host,port:8080,path:apiPath};
            
                var http = require('http');
                var toClient = require('../../../../../toClient');        

                req = http.request(opts, toClient(this,options.call,options.data,cb));
                if (options.data) {
                        req.write(JSON.stringify(options.data));
                }
                apiPath = rawPath;
                req.end();
        }
};

module.exports = {
    
	supported: ['floodlight', 'opendaylight'], //An array of strings, each representing a lower-case version of an SDN controller your adapter supports.

	
	floodlight: {

			TO_OFP: {
                ruleid: "RuleID",
                dpid: "DPID",
                in_port: "InputPort",
                dl_src: "DataLayerSource",
                dl_dst: "DataLayerDestination",
                dl_type: "DataLayerType",
                nw_src_prefix: "NetworkSource_Prefix",
                nw_src_maskbits: "NetworkSource_Mask",
                nw_dst_prefix: "NetworkDestination_Prefix",
                nw_dst_maskbits: "NetworkDestination_Mask",
                nw_proto: "NetworkProtocol",
                tp_src: "TransportSource",
                tp_dst: "TransportDestination",
                wildcard_dpid: "Wildcard_DPID",
                wildcard_in_port: "Wildcard_InputPort",
                wildcard_dl_src: "Wildcard_DataLayerSource",
                wildcard_dl_dst: "Wildcard_DataLayerDestination",
                wildcard_dl_type: "Wildcard_DataLayerType",
                wildcard_nw_src: "Wildcard_NetworkSource",
                wildcard_nw_dst: "Wildcard_NetworkDestination",
                wildcard_nw_proto: "Wildcard_NetworkProtocol",
                wildcard_tp_src: "Wildcard_TransportSource",
                wildcard_tp_dst: "Wildcard_TransportDestination",
                priority: "Priority",
                action: "Action"
            }, //Translations for the normalized API. Keep names consistent between controllers, and consider human-readable, grammatical, and meaningful names.
			
            getFirewallRules: restCall('GET','/wm/firewall/rules/json'), //Create an object with the model identity and a function with http method and controller path for each capability.
             getFirewallStatus: restCall('GET','/wm/firewall/module/status/json'), //single object with status
        enableFirewall: restCall('GET','/wm/firewall/module/enable/json'), //single object with success/failure
        disableFirewall: restCall('GET','/wm/firewall/module/disable/json'), //single object with success/failure

        getFirewallStorageRules: restCall('GET','/wm/firewall/module/storageRules/json'), //unknown
        getFirewallRules: restCall('GET','/wm/firewall/rules/json'), //unknown
        getFirewallSubnetMask: restCall('GET','/wm/firewall/module/subnet-mask/json'), //not an object, just a subnet.
        postFirewallRule: restCall('POST','/wm/firewall/rules/json'),
        deleteFirewallRule: restCall('DELETE','/wm/firewall/rules/json'),
        
            //You can add the following functions: pluginFind, pluginCreate, pluginUpdate, and pluginDestroy
            pluginFind: function(conn, coll, options, cb){
                //console.log("PluginFind was loaded.");
		        switch(coll){
                       case 'firewallrules': return this.getFirewallRules({args:['all'],call:coll},cb);
                        break;
                       case 'firewallstatus':return this.getFirewallStatus({args:[],call:coll},cb);
                        break;
                       case 'disablefirewall':return this.disableFirewall({args:[],call:coll},cb);
                        break;
                        case 'enablefirewall':return this.enableFirewall({args:[],call:coll},cb);
                        break;
                        case 'getFirewallStorageRules':return this.getFirewallStorageRules({args:['all'],call:coll},cb);
                        break;
                       case 'getFirewallSubnetMask':return this.getFirewallSubnetMask({args:['all'],call:coll},cb);
                        break;
                       case 'firewallrules':return this.getFirewallRules({args:['all'],call:coll},cb); 
                         break;
                       default: return cb();
                        break;    
                }
            },
        
            pluginCreate: function(conn, coll, options, cb){
                switch(coll){
                       case 'firewallrules':
                        ruleData = options.data;
                        resp = options.response;
                        
                        if(sails.controllers.main.hostname){
                                  var host = sails.controllers.main.hostname;
                        }
                        var opts = {method:'POST',hostname:host,port:8080,path:'/wm/firewall/rules/json'};
                        //var opts = {method:'POST',hostname:'10.11.17.40',port:8080,path:'/wm/staticflowentrypusher/json'};
                        var requ = http.request(opts,  function(res) {
                          console.log('STATUS: ' + res.statusCode);
                          console.log('HEADERS: ' + JSON.stringify(res.headers));
                          res.setEncoding('utf8');
                          res.on('data', function (chunk) {
                            console.log('BODY: ' + chunk); 
                            var ID = JSON.parse(chunk);  
                            ruleData["rule-id"] = ID["rule-id"];
                            console.log("Modified rule");
                            console.log(ruleData);  
                            resp.send(chunk);   
                          });
                        });
                        
                       console.log(JSON.stringify(ruleData));
                       requ.write(JSON.stringify(ruleData));
                       requ.end();
                         break;
                       default: return cb();
                        break;    
                }
            },
        
            pluginDestroy: function(conn, coll, options, cb){
                switch(coll){
                       case 'firewallrules':
                            var ruleData = options.data;
                            if(sails.controllers.main.hostname){
                              var host = sails.controllers.main.hostname;
                            }
                            var res = res;
                            var options = {
                                hostname:host, 
                                port:8080, 
                                path:'/wm/firewall/rules/json',
                                method:'DELETE'};

                            var req = http.request(options, function(res) {
                              console.log('\n' + 'STATUS: ' + res.statusCode + '\n');
                              console.log('HEADERS: ' + JSON.stringify(res.headers) + '\n');
                              res.setEncoding('utf8');
                              res.on('data', function (chunk) {
                                console.log('BODY: ' + chunk + '\n');
                              });
                            });

                            req.on('error', function(e) {
                              console.log('problem with request: ' + e.message + '\n');
                            });

                            var realData; //temporary fix until find out what front-end parsing is doing
                            for(realData in ruleData){
                                break;
                            }

                            console.log(realData);
                            req.write(realData);
                            req.end(); 
                         break;
                       default: return cb();
                        break;    
                }
            },
            //pluginParse is necessary
            pluginParse: function(current, obj){ 
                return obj;
				//parse raw JSON here to an array of objects like:
				//[{DPID:"XX:XX:XX:XX:XX:XX:XX:XX", SomeModelProperty: 1},
				//{DPID: "XX:XX:XX:XX:XX:XX:XX:X0", SomeModelProperty: 2}]
			  },
    },
    
    opendaylight: {
        
        pluginCreate: function(conn, coll, options, cb){
             //Note: OpenDaylight does not have its own Firewall API. We are pushing flows
             //that allow or block traffic. To identify a flow as a firewall rule, the
             // "isFirewallRule" property is set to true.
            if(options.data){
                if(coll === 'firewallrules'){
                    options.data.isFirewallRule = true;
                    if (options.data.action === 'ALLOW'){
                    options.data.actions = 'output=' + options.data['src-inport'];
                    }
                    else if(options.data.action === 'DENY'){
                    options.data.actions = 'drop=' + options.data['src-inport'];
                    }
                }
            }
            switch(coll){
                case 'firewallrules': return this.create(conn, 'flow', options, cb);
                 break;
                default: return cb();
                 break;           
            }
        }
    }

};

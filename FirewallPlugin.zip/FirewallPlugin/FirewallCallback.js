var http = require('http');
//For ODL: add auth headers
var restCall = function(apiMethod,apiPath){
        var self = this;
        return function(options){
                var rawPath = apiPath;
                if (options.args){
                        for (arg in options.args){
                                apiPath = apiPath.replace(/:[A-Za-z]+:/, options.args[arg]);
                        }
                }
                if(sails.controllers.main.hostname){
                  var host = sails.controllers.main.hostname;
                }
                opts = {method:apiMethod,hostname:host,port:8080,path:apiPath};
            
                var http = require('http');
                var toClient = require('../../../../../toClient');        

                req = http.request(opts, function(){});
                //if (options.data) {
                        //req.write(JSON.stringify(options.data));
                //}
                apiPath = rawPath;
                req.end();
        }
};

module.exports = {
    
 pluginCallback: function(call, options, obj){
    if(options.action){  
            
            //For these to work, if a flow is named with "Rule", toggle the flow on or off
            firewallRules = [];    
            for (var i=0; i<obj.length; i++){
                switchid = obj[i].DPID;
                for(var j=0; j<obj[i].Flows.length; j++){
                    name = obj[i].Flows[j].Flow;
                    if(name.search("Rule") !== -1){
                        rule = {};
                        rule.switchid = switchid;
                        rule.name = name;
                        firewallRules.push(rule);
                    }
                }
            }
        
        for(var k=0; k<firewallRules.length; k++){
            switchid = firewallRules[k].switchid;
            name = firewallRules[k].name;
            options.args = [switchid, name];
            
            switch(options.action){
               case 'disablefirewall':
                case 'enablefirewall':
                var apiPath = '/controller/nb/v2/flowprogrammer/default/node/OF/:switchid:/staticFlow/:name:';
                var apiMethod = 'POST';
                var rawPath = apiPath;
                if (options.args){
                        for (arg in options.args){
                                apiPath = apiPath.replace(/:[A-Za-z]+:/, options.args[arg]);
                        }
                }
                if(sails.controllers.main.hostname){
                  var host = sails.controllers.main.hostname;
                }
                //console.log(apiPath);
                var username = 'admin';
                var password = 'admin';
                var auth = 'Basic ' + new Buffer(username + ':' + password).toString('base64');    
                opts = {method:apiMethod,hostname:host,port:8080,path:apiPath,auth:auth};
                opts.headers = {'Host': opts.hostname + ':' + opts.port, 'Authorization': auth, 'Accept': 'application/json,text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                    'Accept-Encoding': 'gzip,deflate,sdch',
                    'Accept-Language':'en-US,en;q=0.8',
                    'Cache-Control':'max-age=0',
                    'Connection':'keep-alive',
                    'Cookie':'',
                    'User-Agent' : 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.125 Safari/537.36'}; 
                    
                var http = require('http');
                var toClient = require('../../../../../toClient');        

                req = http.request(opts, function(){});
                apiPath = rawPath;
                req.end();
                break;
               default: return cb();
                break;    
            }
        }
        
         delete options.action;
         resObj = {};
         resObj.message = "Action completed, " + firewallRules.length + " rules toggled.";
         return resObj;
    }
            
     else{   
     return obj;
     }
 },
    
    switchFirewallStatus: restCall('POST','/controller/nb/v2/flowprogrammer/default/node/OF/:switchid:/staticFlow/:name:'), 
}
